# HattrickAI — HO 10.0.860 Match Simulation Upgrade

## Source checked

The simulation was compared directly against the bytecode of HO 10.0.860:

- `core.prediction.engine.MatchPredictionManager`
- `core.prediction.engine.MatchData`
- `core.prediction.engine.ActionGenerator`
- `core.prediction.engine.CounterAttackGenerator`
- `core.prediction.engine.BaseActionGenerator`
- `core.prediction.engine.TeamGameData`
- `core.prediction.engine.MatchResult`
- `core.model.match.MatchTacticType`

## Statistical prediction path now mirrors HO

`MatchPredictionManager.calculateMatchResult()` creates `MatchData` and calls `simulate()`.
HO's `ActionGenerator.simulate()` uses **10 iterations per simulated match**, not 91 minutes.
HattrickAI now follows that path for `MatchSimulator.Simulate()`.

Implemented:

- exact 10-iteration statistical loop
- midfield effectiveness based side selection
- HO pressing consumption loop
- exact `BaseActionGenerator.getArea()` distribution
- exact effectiveness curve
- exact `compare()` matchup-probability transformation
- exact `actionNumber` calculation
- HO 10% generic special-event branch with 25%/75% outcome
- tactical counter attack after a failed regular attack
- counter-action limit and midfield condition
- HO counter-action probability constants
- action type `2` for counter attacks
- result aggregation remains compatible with HO's 4x4+ score bucket model

## Detailed path

`MatchSimulator.SimulateDetailed()` also mirrors HO's `ActionGenerator.predict()` / `MatchData.advance()` path:

- minutes 0..90
- per-minute chance allocation
- action quota tracking
- pressing interruption
- normal attacks
- tactical counter attacks
- action minute metadata

This is available for a future match-timeline UI, while statistical recommendation continues to use HO's `simulate()` path.

## Recommendation cleanup

The previous custom `Savunma ağırlıklı` tactic with type `5` was removed from the recommendation candidates. HO's actual tactic IDs represented by the current ActionGenerator are normal (0), pressing (1), counter-attacks (2), attack middle (3), attack wings (4), and play creatively (7). The HO enum also contains long shots as id 8, but this ActionGenerator does not implement the long-shot shooter-vs-goalkeeper branch; it should therefore not be presented as a fully implemented recommendation until that separate model is added.

## Still not claimed as HO-identical

HO's wider match ecosystem contains special-event prediction, long-shot-specific resolution, weather/injury events, and other match-report systems outside `ActionGenerator`. Those are intentionally not fabricated here. The current goal is to make the core statistical action engine match HO first.
