# HO 10.0.860 vs HattrickAI v26 — Simulation Gap Analysis

## Confirmed HO behavior from bytecode

| Component | HO 10.0.860 | HattrickAI v26 |
|---|---|---|
| Statistical result simulation | `MatchPredictionManager.calculateMatchResult()` -> `MatchData.simulate()` | Same 10-iteration statistical path |
| Iterations | 10 per match | 10 |
| Midfield action split | `getEffectiveness(home midfield)` | Same |
| Pressing in statistical path | shared pressing loop, max 7 consumed | Same |
| Regular attack area | 40% middle, AIM +3/level, AOW -1.5/level | Same |
| Matchup conversion | attack/defence linear matchup -> effectiveness | Same |
| Generic special-event branch | 10%; success 25% or 75% | Same |
| Tactical counter after failed attack | yes | Same |
| Counter midfield condition | CA team's matchup midfield <= 0.5 | Same |
| Counter count | formula + random integer, capped at 3 | Same |
| Counter action type | 2 | 2 |
| Result score buckets | scores above 4 are placed in 4 bucket | Same |
| Detailed minute path | 0..90, `predict(minute)` | Added as `SimulateDetailed()` |

## Important finding

The old HattrickAI simulator was **not actually HO-equivalent** despite using some of the same formulas. It selected a team for each of ten actions, applied pressing only to the defender, used a custom 1.10 counter modifier, and used a 32%/25% special-event proxy. Those behaviors have been removed from the core statistical simulator.

## Tactic scope

HO's current CHPP documentation lists normal (0), pressing (1), counter-attacks (2), attack in the middle (3), attack in wings (4), and play creatively (7). HO's internal enum also contains long shots (id 8), but the inspected `ActionGenerator` does not contain the long-shot shooter-vs-goalkeeper resolution. Therefore HattrickAI does not pretend that long shots are fully simulated yet.

## Remaining larger HO systems

These are separate from the inspected `ActionGenerator` statistical core and should be implemented only after their exact source behavior is extracted:

- long-shot shooter vs goalkeeper resolution
- full special-event prediction and specialty-specific outcomes
- weather special events
- set-piece/penalty event branches
- injury/fatigue match-event branches
- tactical/attitude interactions that belong to the rating prediction model rather than ActionGenerator

Those are deliberately marked as future work instead of being replaced by arbitrary modifiers.
