# HattrickAI_v13 OAuth

Bu sürüm CHPP OAuth 1.0a akışını HO!'nun dağıtılan 10.0.860.0 sürümündeki Connector/OAuthDialog mimarisine göre uygular.

- OAuth service mantığı: Consumer Key + Consumer Secret + HattrickAPI endpointleri
- Request token: POST `request_token.ashx`, `no oauth_callback (same as HO! ServiceBuilder)`
- Authorize URL: `authorize.aspx?oauth_token=<request token>&scope=set_matchorder,manage_youthplayers`
- Verification code: kullanıcı Hattrick'ten alır
- Access token: POST `access_token.ashx` + request token + verifier
- Normal CHPP XML çağrıları: OAuth imzalı GET
- İmza: HMAC-SHA1, OAuth RFC 3986 encoding, ScribeJava 8.3.3 tarzı parametre normalizasyonu

Kaynak olarak HO! 10.0.860.0 portable/dev build içindeki `core.net.Connector`, `core.net.HattrickAPI` ve `core.net.login.OAuthDialog` incelenmiştir. Kod ScribeJava'nın C# eşleniği olarak bağımsız uygulanmıştır; Java binary'si projeye dahil edilmez.
