# CHPP implementation notes

This implementation follows the current Hattrick CHPP OAuth 1.0a flow and XML-only access requirement.

OAuth endpoints used:
- request token: https://chpp.hattrick.org/oauth/request_token.ashx
- authorize: https://chpp.hattrick.org/oauth/authorize.aspx
- access token: https://chpp.hattrick.org/oauth/access_token.ashx
- protected XML: https://chpp.hattrick.org/chppxml.ashx

The first mobile version uses `no oauth_callback (same as HO! ServiceBuilder)`, so the user can enter the verifier returned by Hattrick. This matches HO! 10.0.860.0. The production web version should use an HTTPS callback on the backend so the consumer secret remains server-side.

The app sets User-Agent to `HattrickAI/1.0` as required by the CHPP manual.

The initial data path is:

CHPP OAuth -> teamdetails -> own TeamID -> players -> PlayerData -> existing HOEngine -> BestLineup/Recommendation/Simulation

Only the XML interfaces are used by the CHPP path. Hattrick's CHPP manual states that XML is the permitted application data interface.


## OAuth mobil test notu

Hattrick CHPP OAuth uçları için request-token ve access-token istekleri OAuth 1.0a ile imzalanarak HO! ile aynı şekilde POST olarak gönderilir; korunan XML istekleri GET olarak imzalanır.

Consumer Secret son kullanıcıdan istenmez. Yerel geliştirici testinde ortam değişkenlerinden alınır ve cihazın SecureStorage alanında tutulabilir. Üretim web sürümünde consumer secret sunucu tarafında tutulmalıdır.
