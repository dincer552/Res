using HattrickAI.CHPP;
using HattrickAI.HOEngine;

namespace HattrickAI;

public partial class MainPage : ContentPage
{
    private List<PlayerData> _players = new();
    private TeamData? _selectedOpponent;
    private ChppSelectedMatch? _selectedMatch;
    private int _teamId;
    private string _teamName = "";
    private ChppOAuthClient? _oauth;
    private List<PlayerData> _opponentPlayers = new();
    private List<PlayerData> _opponentLineup = new();
    private List<PlayerData> _ownDisplayedLineup = new();
    private ChppOpponentMatch? _selectedOpponentMatch;
    private string _displayFormation = "4-4-2";

    private readonly BestLineupEngine _bestLineupEngine = new();
    private readonly OpponentAnalysisEngine _opponentAnalysisEngine = new();
    private readonly RecommendationEngine _recommendationEngine = new();

    public MainPage()
    {
        InitializeComponent();
    }

    private async void OnConnectClicked(object sender, EventArgs e)
    {
        try
        {
            StatusLabel.Text = "CHPP bağlantısı hazırlanıyor...";

            var credentials = await ChppSettings.LoadAsync();
            if (credentials == null)
            {
                await DisplayAlert("CHPP yapılandırması eksik", "CHPP geliştirici kimlik bilgileri yapılandırılamadı.", "Tamam");
                return;
            }

            _oauth = new ChppOAuthClient(credentials, requestedScopes: ChppSettings.RequestedScopes);
            var accessToken = await _oauth.GetStoredAccessTokenAsync();

            if (accessToken != null)
            {
                StatusLabel.Text = "Mevcut CHPP bağlantısı doğrulanıyor...";
                if (!await _oauth.ValidateStoredAccessTokenAsync())
                {
                    accessToken = null;
                    StatusLabel.Text = "Eski CHPP oturumu geçersiz. Yeni yetkilendirme başlatılıyor...";
                }
            }

            if (accessToken == null)
            {
                StatusLabel.Text = "Hattrick yetkilendirme sayfası açılıyor...";
                var authorizeUrl = await _oauth.BeginAuthorizationAsync();
                await Launcher.Default.OpenAsync(new Uri(authorizeUrl));

                var permissionText = string.IsNullOrWhiteSpace(ChppSettings.RequestedScopes)
                    ? "yalnızca Okuma erişimine"
                    : "istenen CHPP izinlerine";

                var verifier = await DisplayPromptAsync(
                    "Hattrick onay kodu",
                    $"Hattrick'te Team Eleven Helper için {permissionText} izin verdikten sonra gösterilen doğrulama kodunu buraya gir.",
                    "Bağlantıyı tamamla", "İptal", placeholder: "Doğrulama kodu");

                if (string.IsNullOrWhiteSpace(verifier))
                {
                    StatusLabel.Text = "CHPP doğrulaması iptal edildi.";
                    return;
                }

                StatusLabel.Text = "CHPP erişim anahtarı alınıyor...";
                await _oauth.CompleteAuthorizationAsync(verifier);
            }

            StatusLabel.Text = "Takım ve oyuncu verileri CHPP'den okunuyor...";

            var dataService = new ChppTeamDataService(_oauth);
            var snapshot = await dataService.LoadOwnTeamAsync();

            _teamId = snapshot.TeamId;
            _teamName = snapshot.TeamName;
            _players = snapshot.Players;

            if (_players.Count == 0)
                throw new InvalidDataException("CHPP bağlantısı başarılı fakat oyuncu listesi boş geldi.");

            TeamLabel.Text = $"{snapshot.TeamName} • {_players.Count} oyuncu • CHPP";

            var lineup = _bestLineupEngine.FindBestLineup(_players);
            _ownDisplayedLineup = lineup;
            _displayFormation = _bestLineupEngine.LastFormationName;
            SimulationLabel.Text = _bestLineupEngine.GetLineupSummary(lineup);
            FormationLabel.Text = _displayFormation;
            TacticLabel.Text = "Dengeli";
            UpdatePitchHeader();

            StatusLabel.Text = "Güncel maç fikstürü CHPP'den alınıyor...";
            await LoadFixturesAsync();

            ChppConnectButton.Text = "🟢 Hattrick bağlı";
            ChppConnectButton.BackgroundColor = Color.FromArgb("#2E7D32");
            ChppConnectButton.TextColor = Colors.White;
            StatusLabel.Text = $"CHPP bağlantısı başarılı. {_teamName} için maç seçebilirsin.";
        }
        catch (OperationCanceledException)
        {
            StatusLabel.Text = "CHPP bağlantısı iptal edildi.";
        }
        catch (Exception ex)
        {
            StatusLabel.Text = "CHPP bağlantı hatası.";
            await DisplayAlert("CHPP Hatası", ex.Message, "Tamam");
        }
    }

    private async Task LoadFixturesAsync()
    {
        if (_oauth == null || _teamId <= 0)
            return;

        var service = new ChppMatchDataService(_oauth);
        var fixtures = await service.LoadUpcomingFixturesAsync(_teamId);
        FixtureCollectionView.ItemsSource = fixtures;
        FixtureCollectionView.SelectedItem = null;

        if (fixtures.Count == 0)
        {
            SelectedFixtureLabel.Text = "Yaklaşan maç bulunamadı.";
            OpponentLabel.Text = "CHPP yakın gelecek için maç döndürmedi.";
            OpponentHistoryLabel.Text = "—";
            return;
        }

        SelectedFixtureLabel.Text = $"{fixtures.Count} yaklaşan maç bulundu. Öneri almak istediğin maçı seç.";
        OpponentLabel.Text = "Bir maç seçildiğinde rakibin son 5 tamamlanmış maçı CHPP'den okunacak.";
        OpponentHistoryLabel.Text = "—";
    }

    private async void OnFixtureSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is not ChppFixture fixture || _oauth == null)
            return;

        try
        {
            StatusLabel.Text = $"{fixture.OpponentName(_teamId)} rakibinin son maçları alınıyor...";
            SelectedFixtureLabel.Text =
                $"Seçilen maç: {fixture.HomeTeamName} - {fixture.AwayTeamName}\n" +
                $"{fixture.MatchDate:dd.MM.yyyy HH:mm} • {GetMatchTypeName(fixture.MatchType)} • {fixture.VenueText(_teamId)}";

            var service = new ChppMatchDataService(_oauth);
            _selectedMatch = await service.LoadSelectedMatchAsync(fixture, _teamId);
            _selectedOpponentMatch = _selectedMatch.RecentMatches.FirstOrDefault();
            _selectedOpponent = _selectedOpponentMatch?.OpponentTeam ?? _selectedMatch.OpponentRatings;
            OpponentHistoryCollectionView.ItemsSource = _selectedMatch.RecentMatches;
            OpponentHistoryCollectionView.SelectedItem = _selectedOpponentMatch;

            // Rakibin oyuncu listesini de al; maç ekranında gerçek isimleri göstereceğiz.
            try
            {
                var opponentService = new ChppTeamDataService(_oauth);
                var opponentSnapshot = await opponentService.LoadTeamAsync(
                    _selectedMatch.OpponentTeamId,
                    _selectedMatch.OpponentTeamName);
                _opponentPlayers = opponentSnapshot.Players;
            }
            catch
            {
                _opponentPlayers = new List<PlayerData>();
            }

            _ownDisplayedLineup = _bestLineupEngine.FindBestLineupForFormation(_players, _displayFormation);
            _opponentLineup = _opponentPlayers.Count >= 11
                ? _bestLineupEngine.FindBestLineupForFormation(_opponentPlayers, _displayFormation)
                : new List<PlayerData>();
            RenderMatchPitches();

            OpponentLabel.Text =
                $"Rakip: {_selectedMatch.OpponentTeamName}\n" +
                $"Son 5 maç ortalama ratingi:\n{FormatTeamRatings(_selectedOpponent)}";

            OpponentHistoryLabel.Text = FormatOpponentHistory(_selectedMatch);
            UpdateSelectedOpponentMatchLabel();
            StatusLabel.Text = "Maç seçildi. Son maçlardan birini seçerek analizin temelini değiştirebilirsin.";
        }
        catch (Exception ex)
        {
            _selectedMatch = null;
            _selectedOpponent = null;
            StatusLabel.Text = "Rakip geçmişi alınamadı.";
            await DisplayAlert("Rakip maçları", ex.Message, "Tamam");
        }
    }

    private void OnOpponentHistorySelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is not ChppOpponentMatch match)
            return;

        _selectedOpponentMatch = match;
        _selectedOpponent = match.OpponentTeam;
        UpdateSelectedOpponentMatchLabel();

        // The selected historical match becomes the simulation baseline.
        // We deliberately keep the fixture itself unchanged.
        if (_selectedMatch != null)
        {
            OpponentLabel.Text =
                $"Rakip: {_selectedMatch.OpponentTeamName}\n" +
                $"Analiz için seçilen maç: {match.Fixture.MatchDate:dd.MM.yyyy}\n" +
                $"Ratingler (normalize):\n{FormatTeamRatings(match.OpponentTeam)}";
        }

        PitchStatusLabel.Text =
            $"Rakip geçmişinden seçilen maç: {match.Fixture.MatchDate:dd.MM} • {match.Fixture.ScoreText} • {match.OpponentTeam.TacticType switch { 1 => "Pres", 2 => "Kontra", 3 => "Ortadan", 4 => "Kanatlardan", 7 => "Yaratıcı", _ => "Dengeli" }}";
    }

    private void UpdateSelectedOpponentMatchLabel()
    {
        if (_selectedOpponentMatch == null)
        {
            SelectedOpponentMatchLabel.Text = "Seçilen rakip maçı: —";
            return;
        }

        var f = _selectedOpponentMatch.Fixture;
        SelectedOpponentMatchLabel.Text =
            $"Seçilen rakip maçı: {f.MatchDate:dd.MM.yyyy HH:mm} • {f.HomeTeamName} {f.ScoreText} {f.AwayTeamName}";
    }

    private async void OnResetChppClicked(object sender, EventArgs e)
    {
        var confirm = await DisplayAlert("CHPP bağlantısını sıfırla", "Bu cihazdaki CHPP OAuth oturumu silinecek.", "Sıfırla", "İptal");
        if (!confirm) return;

        if (_oauth != null)
        {
            try
            {
                StatusLabel.Text = "Hattrick CHPP erişimi iptal ediliyor...";
                await _oauth.InvalidateStoredAccessTokenAsync();
            }
            catch { }
        }

        ChppSettings.Clear();
        _oauth = null;
        ChppConnectButton.Text = "🔐 Hattrick'e bağlan";
        ChppConnectButton.BackgroundColor = Color.FromArgb("#2B6CB0");
        ChppConnectButton.TextColor = Colors.White;
        _players.Clear();
        _opponentPlayers.Clear();
        _opponentLineup.Clear();
        _ownDisplayedLineup.Clear();
        _selectedOpponent = null;
        _selectedOpponentMatch = null;
        _selectedMatch = null;
        _teamId = 0;
        _teamName = "";

        FixtureCollectionView.ItemsSource = null;
        FixtureCollectionView.SelectedItem = null;
        StatusLabel.Text = "CHPP bağlantısı sıfırlandı.";
        TeamLabel.Text = "Takım verisi yüklenmedi";
        SelectedFixtureLabel.Text = "Henüz maç seçilmedi.";
        OpponentLabel.Text = "Seçilen maçın rakip geçmişi burada gösterilecek.";
        OpponentHistoryLabel.Text = "Maç seçildiğinde son 5 tamamlanmış maçın sonuçları ve ratingleri gelecek.";
        OpponentHistoryCollectionView.ItemsSource = null;
        OpponentHistoryCollectionView.SelectedItem = null;
        SelectedOpponentMatchLabel.Text = "Seçilen rakip maçı: —";
        SimulationLabel.Text = "Henüz kadro hesaplanmadı.";
        FormationLabel.Text = "-";
        TacticLabel.Text = "-";
        _displayFormation = "4-4-2";
        ClearPitch(OwnPitchGrid);
        ClearPitch(OpponentPitchGrid);
        PitchOpponentNameLabel.Text = "RAKİP";
        PitchOwnNameLabel.Text = "BENİM TAKIMIM";
        PitchOpponentFormationLabel.Text = "4-4-2";
        PitchOwnFormationLabel.Text = "4-4-2";
        PitchStatusLabel.Text = "Maç seçildiğinde iki takımın dizilişi burada görünür.";
    }

    private async void OnBestLineupClicked(object sender, EventArgs e)
    {
        if (_players.Count < 11)
        {
            await DisplayAlert("CHPP bağlantısı gerekli", "Önce Hattrick'e bağlan. Oyuncular CHPP'den otomatik alınacak.", "Tamam");
            return;
        }

        try
        {
            StatusLabel.Text = "CHPP oyuncularından en iyi kadro hesaplanıyor...";
            var lineup = _bestLineupEngine.FindBestLineup(_players);
            _ownDisplayedLineup = lineup;
            _displayFormation = _bestLineupEngine.LastFormationName;
            if (_selectedMatch != null && _opponentPlayers.Count >= 11)
                _opponentLineup = _bestLineupEngine.FindBestLineupForFormation(_opponentPlayers, _displayFormation);
            RenderMatchPitches();
            var summary = _bestLineupEngine.GetLineupSummary(lineup);
            TeamLabel.Text = $"{_teamName} • {_players.Count} oyuncu • En iyi diziliş: {_bestLineupEngine.LastFormationName}";
            SimulationLabel.Text = summary;
            FormationLabel.Text = _bestLineupEngine.LastFormationName;
            TacticLabel.Text = "Dengeli";
            StatusLabel.Text = "En iyi kadro hesaplandı.";
            await DisplayAlert("EN İYİ KADRO", summary, "Tamam");
        }
        catch (Exception ex)
        {
            StatusLabel.Text = "Kadro hesaplama hatası.";
            await DisplayAlert("Hata", ex.Message, "Tamam");
        }
    }

    private async void OnRecommendTacticClicked(object sender, EventArgs e)
    {
        try
        {
            if (_players.Count < 11)
            {
                await DisplayAlert("CHPP bağlantısı gerekli", "Önce Hattrick'e bağlan.", "Tamam");
                return;
            }

            if (_selectedMatch == null || _selectedOpponent == null)
            {
                await DisplayAlert("Maç seç", "Önce MAÇ SEÇ bölümünden öneri almak istediğin maçı seç.", "Tamam");
                return;
            }

            bool isHome = _selectedMatch.Fixture.IsOwnHome(_teamId);
            StatusLabel.Text = $"{_selectedMatch.OpponentTeamName} geçmişine göre 1000 simülasyon çalışıyor...";

            var recommendation = _recommendationEngine.Recommend(
                _players,
                _selectedOpponent,
                1000,
                isHome);

            if (recommendation == null)
            {
                await DisplayAlert("Öneri oluşturulamadı", "Yeterli oyuncu bulunamadı.", "Tamam");
                return;
            }

            _displayFormation = recommendation.Formation;
            _ownDisplayedLineup = recommendation.Lineup;
            if (_opponentPlayers.Count >= 11)
                _opponentLineup = _bestLineupEngine.FindBestLineupForFormation(_opponentPlayers, _displayFormation);
            RenderMatchPitches();
            var lineupSummary = _bestLineupEngine.GetLineupSummary(recommendation.Lineup, recommendation.Formation, recommendation.BehaviourProfile);

            double ourWin = isHome ? recommendation.Simulation.HomeWinPercentage : recommendation.Simulation.AwayWinPercentage;
            double ourLoss = isHome ? recommendation.Simulation.AwayWinPercentage : recommendation.Simulation.HomeWinPercentage;
            double ourGoals = isHome ? recommendation.Simulation.AverageHomeGoals : recommendation.Simulation.AverageAwayGoals;
            double oppGoals = isHome ? recommendation.Simulation.AverageAwayGoals : recommendation.Simulation.AverageHomeGoals;

            WinLabel.Text = $"{ourWin:F1}%";
            DrawLabel.Text = $"{recommendation.Simulation.DrawPercentage:F1}%";
            LossLabel.Text = $"{ourLoss:F1}%";
            ScoreLabel.Text = $"Tahmini skor  {FormatOurScore(recommendation.Simulation, isHome)}";
            FormationLabel.Text = recommendation.Formation;
            TacticLabel.Text = recommendation.TacticName;
            ExplanationLabel.Text = recommendation.Explanation;
            RatingsLabel.Text = FormatRatings(recommendation.Ratings);

            RecommendationLabel.Text =
                $"Maç: {(_selectedMatch.Fixture.IsOwnHome(_teamId) ? "Ev sahibi" : "Deplasman")}\n" +
                _opponentAnalysisEngine.GetMatchPlan(_selectedOpponent, recommendation.Formation) +
                "\n\n" + lineupSummary +
                $"\n\nMAÇ SİMÜLASYONU (1000):\nKazanma {ourWin:F1}% • Beraberlik {recommendation.Simulation.DrawPercentage:F1}% • Kaybetme {ourLoss:F1}%\n" +
                $"Ortalama skor: {ourGoals:F2} - {oppGoals:F2}";

            SimulationLabel.Text = lineupSummary;
            StatusLabel.Text = "Seçtiğin maça göre öneri hazır.";
        }
        catch (Exception ex)
        {
            StatusLabel.Text = "Öneri hesaplama hatası.";
            await DisplayAlert("Öneri Hatası", ex.Message, "Tamam");
        }
    }

    private void UpdatePitchHeader()
    {
        PitchOwnNameLabel.Text = string.IsNullOrWhiteSpace(_teamName) ? "BENİM TAKIMIM" : _teamName;
        PitchOpponentNameLabel.Text = _selectedMatch?.OpponentTeamName ?? "RAKİP";
        PitchOwnFormationLabel.Text = _displayFormation;
        PitchOpponentFormationLabel.Text = _displayFormation;
    }

    private void RenderMatchPitches()
    {
        UpdatePitchHeader();
        RenderPitch(OwnPitchGrid, _ownDisplayedLineup, _displayFormation, true);
        RenderPitch(OpponentPitchGrid, _opponentLineup, _displayFormation, false);
        PitchStatusLabel.Text = _opponentLineup.Count == 11
            ? $"{_displayFormation} • 11'e 11 • Oyuncu isimleri CHPP'den"
            : $"{_displayFormation} • Rakip oyuncu verisi alınamadı, rakip ratingi kullanılacak.";
    }

    private static void ClearPitch(Grid grid) => grid.Children.Clear();

    private static void RenderPitch(Grid grid, IReadOnlyList<PlayerData> lineup, string formation, bool ownTeam)
    {
        grid.Children.Clear();
        if (lineup.Count != 11)
        {
            var empty = new Label { Text = "Oyuncu kadrosu bekleniyor...", TextColor = Colors.White, FontSize = 11, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center };
            Grid.SetRow(empty, 1); Grid.SetColumn(empty, 2); grid.Children.Add(empty); return;
        }

        var roles = LineupRatingEngine.GetRoles(formation);
        var rows = new int[11];
        for (int i = 0; i < 11; i++)
        {
            rows[i] = roles[i] switch
            {
                PlayerRole.Goalkeeper => 3,
                PlayerRole.LeftDefender or PlayerRole.CentralDefender or PlayerRole.RightDefender => 2,
                PlayerRole.LeftWinger or PlayerRole.CentralMidfielder or PlayerRole.RightWinger or PlayerRole.LeftMidfielder or PlayerRole.RightMidfielder => 1,
                PlayerRole.LeftForward or PlayerRole.CentralForward or PlayerRole.RightForward => 0,
                _ => 1
            };
            if (!ownTeam) rows[i] = 3 - rows[i];
        }

        foreach (var rowGroup in Enumerable.Range(0, 4).Select(row => new { row, indices = Enumerable.Range(0, 11).Where(i => rows[i] == row).ToList() }))
        {
            int[] columns = rowGroup.indices.Count switch
            {
                1 => new[] { 2 },
                2 => new[] { 1, 3 },
                3 => new[] { 0, 2, 4 },
                4 => new[] { 0, 1, 3, 4 },
                5 => new[] { 0, 1, 2, 3, 4 },
                _ => Array.Empty<int>()
            };

            var ordered = rowGroup.indices
                .OrderBy(i => HorizontalRoleOrder(roles[i]))
                .ThenBy(i => i)
                .ToList();

            for (int pos = 0; pos < ordered.Count; pos++)
            {
                int i = ordered[pos];
                var player = lineup[i];
                int col = columns[pos];

                var card = new Border
                {
                    BackgroundColor = ownTeam ? Color.FromArgb("#F4FFF8") : Color.FromArgb("#FFF7F7"),
                    Stroke = ownTeam ? Color.FromArgb("#68C88E") : Color.FromArgb("#E88A8A"),
                    StrokeThickness = 1,
                    Padding = new Thickness(3, 2),
                    Margin = new Thickness(2)
                };
                card.StrokeShape = new RoundRectangle { CornerRadius = 8 };
                card.Content = new VerticalStackLayout
                {
                    Spacing = 0,
                    Children =
                    {
                        new Label { Text = ShortPlayerName(player.Name), FontSize = 9, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#173B27"), HorizontalTextAlignment = TextAlignment.Center, LineBreakMode = LineBreakMode.TailTruncation },
                        new Label { Text = ShortRole(roles[i]), FontSize = 7, TextColor = Color.FromArgb("#557565"), HorizontalTextAlignment = TextAlignment.Center }
                    }
                };
                Grid.SetRow(card, rowGroup.row); Grid.SetColumn(card, col); grid.Children.Add(card);
            }
        }
    }

    private static int HorizontalRoleOrder(PlayerRole role) => role switch
    {
        PlayerRole.LeftDefender or PlayerRole.LeftWinger or PlayerRole.LeftMidfielder or PlayerRole.LeftForward => 0,
        PlayerRole.CentralDefender or PlayerRole.CentralMidfielder or PlayerRole.CentralForward => 1,
        PlayerRole.RightMidfielder or PlayerRole.RightDefender or PlayerRole.RightWinger or PlayerRole.RightForward => 2,
        _ => 1
    };

    private static string ShortPlayerName(string name)
    {
        if (string.IsNullOrWhiteSpace(name)) return "—";
        var parts = name.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var value = parts.Length == 1 ? parts[0] : parts[^1];
        return value.Length > 12 ? value[..12] : value;
    }

    private static string ShortRole(PlayerRole role) => role switch
    {
        PlayerRole.Goalkeeper => "KL",
        PlayerRole.LeftDefender => "SB",
        PlayerRole.CentralDefender => "STP",
        PlayerRole.RightDefender => "SĞB",
        PlayerRole.LeftWinger or PlayerRole.RightWinger => "KN",
        PlayerRole.LeftMidfielder or PlayerRole.RightMidfielder => "İÇ",
        PlayerRole.CentralMidfielder => "OS",
        PlayerRole.LeftForward or PlayerRole.RightForward => "FV",
        PlayerRole.CentralForward => "SF",
        _ => ""
    };

    private static string FormatOpponentHistory(ChppSelectedMatch snapshot)
    {
        var lines = new List<string>();
        foreach (var item in snapshot.RecentMatches)
        {
            var f = item.Fixture;
            lines.Add(
                $"{f.MatchDate:dd.MM}  {f.HomeTeamName} {f.ScoreText} {f.AwayTeamName}\n" +
                $"    MF {item.OpponentTeam.Ratings.Midfield:F1} | DEF {item.OpponentTeam.Ratings.AverageDefence:F1} | ATT {item.OpponentTeam.Ratings.AverageAttack:F1}");
        }
        return string.Join("\n", lines);
    }

    private static string FormatOurScore(SimulationResult simulation, bool isHome)
    {
        var score = simulation.GetMostLikelyScore().Split('-');
        if (score.Length != 2) return "-";
        return isHome ? simulation.GetMostLikelyScore() : $"{score[1]}-{score[0]}";
    }

    private static string GetMatchTypeName(int type) => type switch
    {
        1 => "Lig",
        2 => "Baraj",
        3 => "Kupa",
        4 => "Dostluk",
        5 => "Dostluk Kupa",
        7 => "Masters",
        8 => "Uluslararası dostluk",
        9 => "Uluslararası dostluk kupa",
        _ => $"Maç türü {type}"
    };

    private static string FormatTeamRatings(TeamData team)
    {
        var ratings = team.Ratings;
        return $"Orta saha: {ratings.Midfield:F2}\n" +
               $"Defans: Sol {ratings.LeftDefence:F2} • Merkez {ratings.CentralDefence:F2} • Sağ {ratings.RightDefence:F2}\n" +
               $"Hücum: Sol {ratings.LeftAttack:F2} • Merkez {ratings.CentralAttack:F2} • Sağ {ratings.RightAttack:F2}";
    }

    private static string FormatRatings(TeamRatings ratings) =>
        $"Orta saha: {ratings.Midfield:F2}\n" +
        $"Defans: Sol {ratings.LeftDefence:F2} • Merkez {ratings.CentralDefence:F2} • Sağ {ratings.RightDefence:F2}\n" +
        $"Hücum: Sol {ratings.LeftAttack:F2} • Merkez {ratings.CentralAttack:F2} • Sağ {ratings.RightAttack:F2}";

    protected override void OnSizeAllocated(double width, double height)
    {
        base.OnSizeAllocated(width, height);
        if (width <= 0) return;

        bool mobile = width < 760;
        Sidebar.IsVisible = !mobile;
        BottomNav.IsVisible = mobile;
        BestLineupButton.IsVisible = !mobile;

        RootLayout.ColumnDefinitions.Clear();
        RootLayout.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(mobile ? 0 : 88) });
        RootLayout.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });

        if (mobile)
        {
            TopAnalysisGrid.ColumnDefinitions.Clear();
            TopAnalysisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            TopAnalysisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0) });
            Grid.SetColumn(TopAnalysisGrid.Children[1], 0);
            Grid.SetRow(TopAnalysisGrid.Children[1], 1);
            TopAnalysisGrid.RowDefinitions.Clear();
            TopAnalysisGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            TopAnalysisGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            Grid.SetRow(TopAnalysisGrid.Children[0], 0);
            Grid.SetColumn(TopAnalysisGrid.Children[0], 0);
            Grid.SetRow(TopAnalysisGrid.Children[1], 1);
            TopAnalysisGrid.ColumnDefinitions.Clear();
            TopAnalysisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            TopAnalysisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0) });
            PitchComparisonGrid.ColumnDefinitions.Clear();
            PitchComparisonGrid.RowDefinitions.Clear();
            PitchComparisonGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            PitchComparisonGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            PitchComparisonGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            PitchComparisonGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            Grid.SetColumn(OpponentPitchGrid.Parent, 0);
            Grid.SetRow(OpponentPitchGrid.Parent, 0);
            Grid.SetColumn(OpponentPitchGrid.Parent.Parent, 0);
            Grid.SetRow(OpponentPitchGrid.Parent.Parent, 0);
            Grid.SetColumn(OwnPitchGrid.Parent, 0);
            Grid.SetRow(OwnPitchGrid.Parent, 1);
            Grid.SetColumn(OwnPitchGrid.Parent.Parent, 0);
            Grid.SetRow(OwnPitchGrid.Parent.Parent, 1);
            Grid.SetColumn(PitchComparisonGrid.Children[1], 0);
            Grid.SetRow(PitchComparisonGrid.Children[1], 2);
            RecommendationGrid.ColumnDefinitions.Clear();
            RecommendationGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            RecommendationGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(0) });
            Grid.SetColumn(RecommendationGrid.Children[0], 0);
            Grid.SetRow(RecommendationGrid.Children[0], 0);
            Grid.SetColumn(RecommendationGrid.Children[1], 0);
            Grid.SetRow(RecommendationGrid.Children[1], 1);
            RecommendationGrid.RowDefinitions.Clear();
            RecommendationGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            RecommendationGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
        }
        else
        {
            TopAnalysisGrid.RowDefinitions.Clear();
            TopAnalysisGrid.ColumnDefinitions.Clear();
            TopAnalysisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.05, GridUnitType.Star) });
            TopAnalysisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.95, GridUnitType.Star) });
            Grid.SetColumn(TopAnalysisGrid.Children[0], 0);
            Grid.SetColumn(TopAnalysisGrid.Children[1], 1);
            PitchComparisonGrid.RowDefinitions.Clear();
            PitchComparisonGrid.ColumnDefinitions.Clear();
            PitchComparisonGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            PitchComparisonGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            PitchComparisonGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            Grid.SetColumn(OpponentPitchGrid.Parent.Parent, 0);
            Grid.SetRow(OpponentPitchGrid.Parent.Parent, 0);
            Grid.SetColumn(PitchComparisonGrid.Children[1], 1);
            Grid.SetRow(PitchComparisonGrid.Children[1], 0);
            Grid.SetColumn(OwnPitchGrid.Parent.Parent, 2);
            Grid.SetRow(OwnPitchGrid.Parent.Parent, 0);
            RecommendationGrid.RowDefinitions.Clear();
            RecommendationGrid.ColumnDefinitions.Clear();
            RecommendationGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.2, GridUnitType.Star) });
            RecommendationGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Star });
            Grid.SetColumn(RecommendationGrid.Children[0], 0);
            Grid.SetColumn(RecommendationGrid.Children[1], 1);
            Grid.SetRow(RecommendationGrid.Children[0], 0);
            Grid.SetRow(RecommendationGrid.Children[1], 0);
        }
    }

}
