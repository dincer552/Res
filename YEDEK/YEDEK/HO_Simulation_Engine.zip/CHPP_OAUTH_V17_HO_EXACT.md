# CHPP OAuth v18 – HO/ScribeJava exact token flow

- Request token: POST `https://chpp.hattrick.org/oauth/request_token.ashx`
- Request token includes `oauth_callback=oob`.
- Access token: POST `https://chpp.hattrick.org/oauth/access_token.ashx`.
- Both token exchanges use OAuth 1.0a HMAC-SHA1 and an `Authorization: OAuth ...` header.
- This matches the behavior observed in HO! 10.0.860 using ScribeJava 8.3.3 (`DefaultApi10a` + `OAuth10aService`).
- Extended permissions are appended to the authorization URL after the request token is obtained, matching HO! `OAuthDialog`: `set_matchorder,manage_youthplayers`.
- Protected CHPP XML resources remain GET requests signed with the access token.
- The previous v16 401 query-string fallback was removed; it was not part of HO/ScribeJava and could obscure the actual token-flow behavior.
