# CHPP geliştirici kurulumu

Son kullanıcı Consumer Key/Secret görmez.

Windows PowerShell'de uygulamayı çalıştırmadan önce:

```powershell
$env:HATTRICK_CHPP_CONSUMER_KEY="BURAYA_CONSUMER_KEY"
$env:HATTRICK_CHPP_CONSUMER_SECRET="BURAYA_YENI_CONSUMER_SECRET"
```

Sonra Visual Studio'yu aynı PowerShell oturumundan açın veya bu değişkenleri sistem/kullanıcı ortam değişkeni olarak tanımlayın.

Güvenliği artırmak için Consumer Secret'ı kaynak koda, Git'e veya ZIP'e düz metin olarak koymayın. Gerçek dağıtımda daha güvenli çözüm, OAuth işlemini sunucu tarafında yapmak ve mobil istemciye yalnızca kullanıcı oturumunu vermektir.
