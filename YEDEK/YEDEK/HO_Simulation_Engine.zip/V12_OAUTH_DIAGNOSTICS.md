# HattrickAI v12 OAuth teşhis modu

`HattrickAI/CHPP/ChppOAuthDiagnostics.cs` OAuth 1.0a isteklerini loglar.

Log konumu: MAUI `FileSystem.AppDataDirectory` altında `hattrickai_v13_oauth_diagnostics.log`.

Loglanan alanlar:
- HTTP yöntemi
- tam istek URL
- OAuth parametreleri
- signature base string
- imza
- HTTP durum kodu ve başlıkları
- yanıt gövdesi

Consumer Secret ve token secret değerleri logda maskelenir.


401 durumunda uygulamanın hata penceresi log dosyasının tam yolunu da gösterir. Teşhis için özellikle `REQUEST TOKEN` bölümünü gönderin. `CONSUMER SECRET`, `oauth_token_secret` ve diğer secret alanları otomatik maskelenir.
