# HattrickAI v25 UI Focus

The UI is intentionally focused on the core product goal: pre-match analysis, simulation and recommendation.

Removed from primary navigation:
- Ana Sayfa
- Takım
- Raporlar
- Ayarlar
- Yardım
- Separate Simülasyon screen

Kept:
- Maç Analiz
- Fikstür
- Oyuncular (lightweight data only)

The existing CHPP, fixture, opponent-match, rating and simulation code is preserved. This change is UI/navigation scope only.
