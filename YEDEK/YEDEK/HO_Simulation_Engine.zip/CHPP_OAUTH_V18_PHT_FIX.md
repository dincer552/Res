# CHPP OAuth v18 – PHT-compatible GET query flow

## Why v17 still failed

The diagnostic log showed repeated 401 responses from the request-token endpoint even after `oauth_callback=oob` was added. The v17 implementation was still centered on ScribeJava's Authorization-header transport.

For CHPP, the better reference implementation is PHT v3. Its current source builds the request-token and access-token OAuth requests as **GET URLs containing the complete OAuth parameter set in the query string**, including `oauth_callback`, `oauth_signature`, and (for access-token) `oauth_token` + `oauth_verifier`.

PHT also builds the OAuth signature using HMAC-SHA1, RFC3986 encoding, sorted encoded parameter names, and a signing key of `consumerSecret&tokenSecret`.

## v18 changes

- Request-token exchange: **GET + OAuth query parameters** (PHT-compatible).
- `oauth_callback=oob` is included in both the signed parameter set and final URL.
- Access-token exchange: **GET + OAuth query parameters**.
- `oauth_token` and `oauth_verifier` are included in the signed parameter set.
- Every retry gets a fresh timestamp + nonce.
- If PHT-style GET query fails, v18 tries a fresh **GET Authorization-header** request as a secondary compatibility path.
- Removed the v16/v17 POST-first behavior and the old 401 query fallback.
- `#_=_` is stripped from the verifier, matching PHT's defensive handling.
- Extended scopes remain on `authorize.aspx`, not on request-token.

## External reference

PHT v3 source: https://github.com/jetwitaussi/PHT

Relevant files: `PHT/Network/Auth.php`, `PHT/Network/Request.php`, `PHT/Network/Url.php`.
