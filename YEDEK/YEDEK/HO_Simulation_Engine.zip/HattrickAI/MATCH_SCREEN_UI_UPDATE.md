# Match Screen UI Update

- Added a football-match style pitch showing both teams.
- Selected formation is rendered with 11 player cards.
- Opponent player names are loaded from CHPP when available.
- Selecting a fixture refreshes both lineups.
- Recommendation formation updates the pitch for both teams.
