# HattrickAI CHPP OAuth v16 fix

This revision addresses the observed Hattrick 401 responses from v15.

## Changes

- Keeps OAuth 1.0a + HMAC-SHA1.
- Keeps GET for all OAuth endpoints, per the current CHPP guide.
- Keeps `oauth_callback=oob` for the native/OOB flow.
- Normalizes OAuth parameters by OAuth-encoded key/value before sorting, then encodes the normalized parameter string.
- Makes the Authorization header deterministic and OAuth-encodes both keys and values.
- If Hattrick returns HTTP 401 for the request-token or access-token Authorization-header form, retries the exact same signed OAuth request with all OAuth parameters carried in the GET query string. This is a transport fallback; the signature base string is unchanged.
- Adds diagnostics for the fallback transport.
- Uses a CHPP-compliant User-Agent: `HattrickAI, v15.1`.
- Extended scopes remain opt-in and are only placed on `authorize.aspx`.

## Why

The supplied diagnostic log showed repeated 401 responses both before and after switching from POST to GET and adding `oauth_callback=oob`. The new implementation therefore avoids assuming that the remaining problem is the OAuth algorithm alone and supports the other standard OAuth parameter transport used by CHPP-compatible clients.

## Important

If both header and query transports still return 401, the remaining likely cause is the CHPP product credential pair (Consumer Key/Consumer Secret) or the product's approval/status on Hattrick. The application cannot fix an invalid server-side credential pair.
