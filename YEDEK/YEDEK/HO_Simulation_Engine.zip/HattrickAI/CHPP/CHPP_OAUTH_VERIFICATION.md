# OAuth signing verification

The C# signing implementation was checked against ScribeJava 8.3.3's actual `BaseStringExtractorImpl` and `HMACSha1SignatureService` using the same fixed GET request, query parameters, OAuth parameters, consumer secret and token secret.

Result: generated OAuth signature and signature base string matched ScribeJava exactly.

The comparison covered:

- query parameters included in the signature base string;
- raw key/value sorting before encoding;
- OAuth percent-encoding behavior;
- sanitized URL without query string;
- HMAC-SHA1;
- consumer-secret/token-secret signing key construction.


## v16 401 mitigation

The v13 diagnostics showed HTTP 401 for both POST and GET request-token attempts, including GET with `oauth_callback=oob`. v16 therefore adds a standards-compatible query-parameter fallback after a 401 while retaining the same signed parameter set. This makes it possible to distinguish a transport/parser issue from invalid CHPP credentials.
