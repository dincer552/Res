# HattrickAI v23

## Fixes
- CHPP `matchdetails` ratings are normalized from the documented 1..80 scale to the HO-style 0..20-ish scale before entering the simulator.
- The last five completed opponent matches are now selectable in the UI.
- Selecting an opponent history match changes the opponent baseline used by the recommendation engine; it no longer always averages the five matches.
- The selected historical match and normalized ratings are shown in the UI.
- Hattrick tactic type 7 is treated as Creative Play, matching the CHPP matchDetails documentation. The previous fake type-6 creative / type-7 long-shot split was removed.

## Important
The match simulator is still a simplified HO-style simulator, not a byte-for-byte reproduction of the full HO match engine. This release fixes a concrete data-scale error that could make matchups wildly one-sided.
