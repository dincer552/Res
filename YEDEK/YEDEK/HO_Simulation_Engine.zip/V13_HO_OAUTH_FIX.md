# HattrickAI v13 — HO OAuth düzeltmesi

Bu sürüm v12 teşhis logundan ve HO! kaynak kodundan çıkarılan kritik farkı düzeltir.

## Kritik fark

HO! `Connector` içinde:

`new ServiceBuilder(...).apiSecret(...).build(HattrickAPI.instance())`

kullanıyor ve **callback tanımlamıyor**.

Dolayısıyla ScribeJava'nın request-token isteğinde `oauth_callback` parametresi gönderilmiyor.

v12 ise `oauth_callback=oob` gönderiyordu. Bu, OAuth imzasını değiştirir.

v13:
- POST `request_token.ashx`
- `oauth_callback` YOK
- HMAC-SHA1
- OAuth Authorization header
- Hattrick authorize URL'si: `authorize.aspx?oauth_token=<TOKEN>&scope=set_matchorder,manage_youthplayers`
- POST `access_token.ashx`
- HO! ile aynı CHPP endpointleri
- HO! ile uyumlu HTTP Accept / Accept-Language / Accept-Encoding / User-Agent başlıkları

## 401 devam ederse

Bu sürümde request-token isteği HO!'nun OAuth kurulumuna daha yakın hale getirilmiştir. Buna rağmen 401 devam ederse, teşhis logundaki yeni signature base string'i kontrol edilmelidir; ayrıca CHPP ürününün geliştirme aşamasında kullanıcı hesabının Developer/Tester erişimi de kontrol edilmelidir.
