# HattrickAI CHPP kurulumu

Hattrick CHPP onayı alındıktan sonra bu sürüm OAuth 1.0a ile Hattrick'e bağlanabilir.

## 1. Consumer bilgileri

Son kullanıcıdan **Consumer Key** veya **Consumer Secret** istenmez. Bunlar uygulamanın geliştirici/dağıtım yapılandırmasına aittir.

Yerel Windows geliştirme testinde şu ortam değişkenlerini tanımlayın:

- `HATTRICK_CHPP_CONSUMER_KEY`
- `HATTRICK_CHPP_CONSUMER_SECRET`

Uygulama bunları ilk çalıştırmada `SecureStorage` içine alır. Hattrick kullanıcı adı/parolası uygulama tarafından istenmez ve saklanmaz.

## 2. Bağlantı akışı

1. HattrickAI içinde `Hattrick'e bağlan` butonuna bas.
2. Uygulama CHPP request token alır ve Hattrick yetkilendirme sayfasını otomatik açar.
3. Kullanıcı Hattrick CHPP yetkilendirme sayfasında erişim izni verir.
4. Hattrick'te izin ver.
5. Hattrick'in verdiği OAuth doğrulama kodunu uygulamaya gir.
6. Uygulama access token'ı SecureStorage'a kaydeder.
7. Takım detayları ve oyuncu listesi CHPP XML üzerinden çekilir.

## 3. Çekilen ilk veriler

- takım ID / takım adı
- oyuncu ID / ad
- yaş
- form
- tecrübe
- liderlik
- specialty
- kondisyon
- kalecilik
- defans
- oyun kurma
- pas
- kanat
- golcülük
- duran toplar
- sakatlık
- kart/suspension

CHPP oyuncu XML'i kendi takım oyuncuları için bu yetenek alanlarını sağlar. Loyalty alanı mevcut `PlayerData` modelinde tutulmaya devam eder ancak players XML dokümanında bu alan bulunmadığı için bu sürümde CHPP'den uydurma bir değer yazılmaz.

## 4. CHPP kurallarına uyum

CHPP üzerinden yalnızca XML arayüzleri kullanılmalıdır. HTML scraping mevcut offline/manuel yedek akışımız olarak kalır; CHPP bağlantısı XML kullanır.

HTTP User-Agent: `HattrickAI/1.0`
