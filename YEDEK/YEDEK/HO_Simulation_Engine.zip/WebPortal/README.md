# Hattrick AI Web Portal

Static landing/dashboard prototype. It is intentionally independent of the MAUI build.

## Deployment target

The first deployment can use a free static host such as Cloudflare Pages. The `pages.dev` address can be used before a custom domain is purchased.

## CHPP

The button is a visual placeholder only. OAuth secrets and callback handling must be implemented server-side after the CHPP application is approved. Do not put client secrets in this static site.
