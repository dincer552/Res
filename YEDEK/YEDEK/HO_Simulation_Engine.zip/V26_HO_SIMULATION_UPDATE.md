# HattrickAI v26 — HO Match Simulation Core

The match simulation core was upgraded after direct bytecode comparison with HO 10.0.860.

Primary files compared:
- `core.prediction.engine.MatchPredictionManager`
- `core.prediction.engine.MatchData`
- `core.prediction.engine.ActionGenerator`
- `core.prediction.engine.CounterAttackGenerator`
- `core.prediction.engine.BaseActionGenerator`
- `core.prediction.engine.TeamGameData`
- `core.prediction.engine.MatchResult`

The recommendation engine no longer offers the custom type-5 "Savunma ağırlıklı" tactic, because type 5 is not a current HO match tactic ID in the inspected engine.
