# HattrickAI - HO! rating upgrade notes

Bu sürüm, mevcut çalışan HTML tabanlı oyuncu/rakip akışını bozmadan HO! tarzı rating prediction mimarisini genişletir.

## Yapılan revizyonlar

- `PlayerRatingCalculator` form, kondisyon, tecrübe ve opsiyonel loyalty etkilerini tek yerde toplar.
- `RatingContributionTable` pozisyon + davranış + sektör katkısını merkezi hale getirir.
- `LineupRatingEngine` oyuncuyu tek bir toplam puanla değil, yedi rating sektörü üzerinden değerlendirir.
- Sağ/sol/merkez roller desteklenir.
- Hattrick'te yaygın kullanılan 7 diziliş değerlendirmeye açılmıştır:
  - 4-4-2
  - 4-3-3
  - 3-5-2
  - 3-4-3
  - 4-5-1
  - 5-4-1
  - 5-3-2
- Orta defans/orta saha yığılmasına küçük overcrowding cezası eklenmiştir.
- ÖNER sistemi 9 taktik adayını karşılaştırır:
  - Dengeli oyun
  - Pres
  - Kontra atak
  - Ortadan hücum
  - Kanatlardan hücum
  - Savunma ağırlıklı
  - Yaratıcı oyun
  - Uzaktan şut
  - Ofansif oyun
- `MatchSimulator` bu taktiklerin temel etkilerini simülasyona yansıtır.
- Oyuncu HTML parser'ı form/kondisyon/tecrübe satırlarında daha toleranslı hale getirilmiştir.
- MainPage alternatif sayısı artık 7 diziliş x 9 taktik olarak gösterilir.

## Bilinçli sınır

Bu kod HO!'nun kaynak kodunun birebir kopyası değildir. HO!'nun rating prediction yaklaşımındaki katmanlar bağımsız C# koduyla modellenmiştir. Katsayılar CHPP'den gerçek maç ratingleri geldikçe kalibre edilmek üzere merkezi tutulmuştur.

## Test

Bu paket üzerinde `dotnet build` çalıştırılmamıştır. Kullanıcının Visual Studio ortamında derleyip mevcut proje ekranında test etmesi beklenir.
