# HattrickAI_v13

- CHPP OAuth 1.0a akışı HO! 10.0.860.0 davranışına uyarlandı.
- Request token ve access token çağrıları POST yapılıyor.
- `no oauth_callback (same as HO! ServiceBuilder)` korunuyor.
- Authorize URL, gerçek request token ile `oauth_token` ve gerekli scope parametrelerini içeriyor.
- OAuth HMAC-SHA1 imza normalizasyonu ScribeJava 8.3.3 davranışına göre yeniden yazıldı.
- Kullanıcı Consumer Key / Secret girmiyor.
- HTML oyuncu/rakip seçimi UI'dan kaldırılmış akış korunuyor.
- `bin`, `obj`, `.vs` paketlenmiyor.
