using System.Diagnostics;
using System.Net;
using System.Text;

namespace HattrickAI.CHPP;

/// <summary>
/// V12 OAuth diagnostic logger.
/// Logs enough information to compare our OAuth 1.0a request with HO!/ScribeJava
/// without ever writing the Consumer Secret or token secrets to disk.
/// </summary>
public static class ChppOAuthDiagnostics
{
    private static readonly SemaphoreSlim Gate = new(1, 1);

    public static string LogPath => Path.Combine(
        FileSystem.AppDataDirectory,
        "hattrickai_v13_oauth_diagnostics.log");

    public static async Task LogRequestAsync(
        string stage,
        string method,
        string url,
        IReadOnlyDictionary<string, string> oauthParameters,
        string signatureBaseString,
        string signature,
        string consumerKey,
        string consumerSecret)
    {
        var sb = new StringBuilder();
        sb.AppendLine();
        sb.AppendLine("============================================================");
        sb.AppendLine($"UTC: {DateTimeOffset.UtcNow:O}");
        sb.AppendLine($"STAGE: {stage}");
        sb.AppendLine("HTTP METHOD: " + method);
        sb.AppendLine("FULL REQUEST URL: " + url);
        sb.AppendLine("OAUTH PARAMETERS:");

        foreach (var pair in oauthParameters)
        {
            var value = pair.Key.Equals("oauth_token_secret", StringComparison.OrdinalIgnoreCase)
                ? MaskSecret(pair.Value)
                : pair.Value;
            sb.AppendLine($"  {pair.Key} = {value}");
        }

        sb.AppendLine("CONSUMER KEY: " + consumerKey);
        sb.AppendLine("CONSUMER SECRET: " + MaskSecret(consumerSecret));
        sb.AppendLine("SIGNATURE BASE STRING:");
        sb.AppendLine(signatureBaseString);
        sb.AppendLine("SIGNATURE: " + signature);
        sb.AppendLine("------------------------------------------------------------");

        await AppendAsync(sb.ToString());
    }

    public static async Task LogResponseAsync(
        string stage,
        HttpResponseMessage response,
        string body,
        string consumerSecret)
    {
        var safeBody = MaskSensitiveResponse(body);
        var sb = new StringBuilder();
        sb.AppendLine($"RESPONSE STATUS: {(int)response.StatusCode} {response.ReasonPhrase}");
        sb.AppendLine("RESPONSE HEADERS:");
        foreach (var header in response.Headers)
            sb.AppendLine($"  {header.Key}: {string.Join(", ", header.Value)}");

        foreach (var header in response.Content.Headers)
            sb.AppendLine($"  {header.Key}: {string.Join(", ", header.Value)}");

        sb.AppendLine("RESPONSE BODY (secrets masked):");
        sb.AppendLine(safeBody);
        sb.AppendLine("CONSUMER SECRET CHECK: " + MaskSecret(consumerSecret));
        sb.AppendLine("============================================================");

        await AppendAsync(sb.ToString());
    }

    public static async Task LogFallbackAsync(string stage, string url, string signatureBaseString)
    {
        var sb = new StringBuilder();
        sb.AppendLine("FALLBACK TRANSPORT: OAuth parameters moved to GET query after 401");
        sb.AppendLine("FALLBACK URL: " + url);
        sb.AppendLine("SIGNATURE BASE STRING (same signed request):");
        sb.AppendLine(signatureBaseString);
        await AppendAsync(sb.ToString());
    }

    public static async Task ClearAsync()
    {
        await Gate.WaitAsync();
        try
        {
            if (File.Exists(LogPath))
                File.Delete(LogPath);
        }
        finally
        {
            Gate.Release();
        }
    }

    private static async Task AppendAsync(string text)
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(LogPath)!);
            await Gate.WaitAsync();
            try
            {
                await File.AppendAllTextAsync(LogPath, text + Environment.NewLine, Encoding.UTF8);
            }
            finally
            {
                Gate.Release();
            }

            Debug.WriteLine(text);
        }
        catch (Exception ex)
        {
            Debug.WriteLine("OAuth diagnostic logging failed: " + ex);
        }
    }

    private static string MaskSecret(string? value)
    {
        if (string.IsNullOrEmpty(value))
            return "<empty>";

        if (value.Length <= 4)
            return "****";

        return value[..2] + new string('*', Math.Min(value.Length - 4, 20)) + value[^2..];
    }

    private static string MaskSensitiveResponse(string body)
    {
        if (string.IsNullOrEmpty(body))
            return "<empty>";

        var pairs = body.Split('&', StringSplitOptions.RemoveEmptyEntries);
        var output = new List<string>(pairs.Length);

        foreach (var pair in pairs)
        {
            var parts = pair.Split('=', 2);
            if (parts.Length != 2)
            {
                output.Add(pair);
                continue;
            }

            var key = WebUtility.UrlDecode(parts[0]) ?? parts[0];
            if (key.Contains("secret", StringComparison.OrdinalIgnoreCase))
                output.Add(parts[0] + "=<MASKED>");
            else
                output.Add(pair);
        }

        return string.Join('&', output);
    }
}
