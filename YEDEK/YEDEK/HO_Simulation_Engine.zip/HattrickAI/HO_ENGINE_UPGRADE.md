# HattrickAI HO! Rating Upgrade — Test Notes

## What changed

1. `PlayerRatingCalculator`
   - HO! style skill rating (`max(0, skill - 1)`).
   - loyalty + form player strength.
   - experience sector contribution.
   - stamina minute correction and pressing modifier.
   - specialty/weather hooks.

2. `RatingContributionTable`
   - seven rating sectors.
   - left / middle / right side restrictions.
   - role sector mapping: goal, central defence, back, inner midfield, wing, forward.
   - normal/offensive/defensive/towards-middle/towards-wing behaviours.
   - public HO! contribution parameters translated into an independent C# data table.

3. `LineupRatingEngine`
   - HO! sector scaling.
   - overcrowding penalties.
   - tactic/team context.
   - correct winger vs inner-midfield role separation.

4. `BestLineupEngine`
   - 7 common formations.
   - multiple slot-priority passes.
   - position-specific behaviour selection.
   - injured/suspended players excluded.

5. `RecommendationEngine`
   - 8 tactic candidates: balanced, pressing, counter, AIM, AOW, defensive, creative, long shots.
   - tactic-specific rating context.
   - simulation-based selection.
   - explanation text.

6. UI
   - compact dashboard/cards.
   - win/draw/loss probabilities.
   - predicted score.
   - formation/tactic cards.
   - rating sector summary.
   - explanation panel.

7. Training models
   - `TrainingReport`, `TrainingEvent`, `TrainingAnalyzer` prepared for weekly development history.

8. Web prototype
   - `WebPortal/` contains a static professional landing/dashboard prototype.
   - no CHPP secret is embedded.

## Manual test sequence

1. Build the MAUI project.
2. Run on the same Windows/Android target used previously.
3. Choose the same player HTML that previously returned 33 players.
4. Confirm the player count is still correct.
5. Press `En iyi kadro`.
6. Confirm one of the seven supported formations is shown.
7. Select the same opponent match HTML.
8. Select the opponent team.
9. Press `ÖNER`.
10. Confirm probabilities, score, formation, tactic, rating sectors and explanation appear.

## Important

The project was not built in this environment because the .NET SDK is not installed here. This package is therefore intentionally a source revision for the user's local Visual Studio build/test cycle.
