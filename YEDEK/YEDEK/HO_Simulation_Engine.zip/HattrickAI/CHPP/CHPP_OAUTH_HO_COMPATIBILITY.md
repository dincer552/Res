# HattrickAI CHPP OAuth 1.0a

This version aligns the HattrickAI authorization flow with the CHPP OAuth guide and the verification-code flow used by HO!.

## Flow

1. Request a request token from `request_token.ashx`.
2. Send `oauth_callback=oob` as an OAuth parameter.
3. Open `authorize.aspx?oauth_token=...` in the system browser.
4. The user logs in on the Hattrick domain and grants the normal **Read access** permission.
5. Hattrick displays a verification code.
6. HattrickAI asks the user to enter that code.
7. Exchange the request token + verifier for an access token at `access_token.ashx`.
8. Store the access token and secret in MAUI SecureStorage.
9. On subsequent launches, call `check_token.ashx` before trusting the cached token.
10. When the user resets the connection, call `invalidate_token.ashx` and then clear local credentials.

## Permissions

No extended CHPP scope is requested by default. Write permissions such as `set_matchorder` should only be added when a concrete HattrickAI feature requires them.

## HTTP/signing

The OAuth endpoints and protected XML requests use GET and HMAC-SHA1. The OAuth Authorization header is signed using the consumer secret and, for authorized requests, the access/request token secret.

## Security

The Consumer Secret is currently embedded in `ChppSettings.cs` because this is a native client. This is not a way to make a public client secret truly confidential. If the app is distributed publicly, the CHPP secret should be rotated and a backend signing service should be considered. Never store Hattrick user passwords or security codes.
