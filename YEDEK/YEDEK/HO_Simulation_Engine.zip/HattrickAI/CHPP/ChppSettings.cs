namespace HattrickAI.CHPP;

public sealed record ChppCredentials(string ConsumerKey, string ConsumerSecret);

/// <summary>
/// CHPP product credentials for the local desktop/mobile build.
/// End users never enter these values. The first connection starts directly
/// at Hattrick's OAuth authorization page.
///
/// IMPORTANT: a client application cannot truly hide a consumer secret from
/// someone who can inspect its binary. For a public web deployment, move the
/// OAuth signing and consumer secret to the backend.
/// </summary>
public static class ChppSettings
{
    // CHPP product: Team Eleven Helper / HattrickAI.
    // These are intentionally not exposed in the UI.
    private const string ConsumerKey = "4CzYYAnSg7SSHkQyDVMLIV";
    private const string ConsumerSecret = "E2cpVdlt1QOJvBl5JbABhlyuyJz55cS59KpENyAIjML";

    // HO! 10.0.860 OAuthDialog requests these same extended permissions on
    // authorize.aspx. They are NOT sent with request_token and do not affect
    // the OAuth signature. Remove a scope when the corresponding write feature
    // is not needed.
    public const string RequestedScopes = "set_matchorder,manage_youthplayers";

    public static Task<ChppCredentials?> LoadAsync()
    {
        return Task.FromResult<ChppCredentials?>(
            new ChppCredentials(ConsumerKey, ConsumerSecret));
    }

    public static void Clear()
    {
        SecureStorage.Default.Remove(ChppOAuthClient.AccessTokenKey);
        SecureStorage.Default.Remove(ChppOAuthClient.AccessTokenSecretKey);
        SecureStorage.Default.Remove("chpp_request_token");
        SecureStorage.Default.Remove("chpp_request_token_secret");
    }
}
