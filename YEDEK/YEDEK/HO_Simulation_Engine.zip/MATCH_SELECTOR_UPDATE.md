# HattrickAI 1.4 – Match selector / opponent history

- Loads upcoming own fixtures from CHPP `matches` XML v2.2.
- User selects the future match that should receive the recommendation.
- Selected opponent is resolved from the selected fixture, not assumed to be the next match.
- Loads the opponent's last 5 finished matches.
- Loads `matchdetails` v1.4 for those matches and extracts the seven sector ratings and tactic data.
- Builds an average opponent rating profile from those recent matches.
- The recommendation engine now knows whether the selected match is home or away and runs the simulation from the user's perspective.
- The UI shows the selected fixture, opponent history, recent match scores and rating summaries.

The project already targets `net9.0-android`; producing an APK requires the .NET MAUI Android workload and Android SDK/keystore on the build machine.
