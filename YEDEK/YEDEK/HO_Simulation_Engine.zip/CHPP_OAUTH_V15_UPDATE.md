# HattrickAI CHPP OAuth 1.0a – v15 update

This revision reconciles the real HO! 10.0.860 OAuth implementation (ScribeJava 8.3.3) with the current Hattrick CHPP OAuth requirements.

## What was matched to HO!/ScribeJava

- OAuth Core 1.0a.
- HMAC-SHA1 signatures.
- OAuth Authorization header signatures.
- `oauth_callback=oob` for the desktop/native no-callback flow.
- Request token -> browser authorization -> verification code -> access token.
- Access-token requests include the request token and `oauth_verifier` and are signed with the request-token secret.
- Protected CHPP XML requests are signed with the access-token secret.
- OAuth parameter normalization follows ScribeJava's `ParameterList`/`BaseStringExtractorImpl` behavior: query + body + OAuth parameters, sort by raw key/value, encode each pair, then OAuth-encode the complete normalized string.
- HMAC signing key is OAuth-encoded `consumerSecret + '&' + tokenSecret`.
- Authorization header values are OAuth-encoded and the signature is appended after the OAuth parameters.

## Where the current CHPP guide takes precedence

HO! 10.0.860 relies on ScribeJava's `DefaultApi10a` defaults, which use POST for request-token/access-token unless the provider overrides them. The current Hattrick CHPP guide explicitly says to use GET for all OAuth requests, so HattrickAI uses GET for request-token, access-token, check-token and invalidate-token.

HO! also appends `&scope=set_matchorder,manage_youthplayers` to its authorization URL. HattrickAI does not request write scopes by default because the current feature set only needs read access. `ChppSettings.RequestedScopes` is available for a future feature to request exact CHPP write permissions such as `set_matchorder`.

## Token lifecycle

1. `BeginAuthorizationAsync()` obtains a request token with a signed GET and `oauth_callback=oob`.
2. The app opens Hattrick's `authorize.aspx` URL.
3. Hattrick authenticates the user and shows the requested permission(s).
4. With OOB authorization, Hattrick shows a verification code.
5. `CompleteAuthorizationAsync(verifier)` exchanges the request token + verifier for the access token.
6. Access token and token secret are stored in MAUI SecureStorage.
7. On startup, `check_token.ashx` validates a cached token before use.
8. Reset calls `invalidate_token.ashx` and then removes local credentials.

## Security

- Hattrick credentials are never collected by HattrickAI.
- User access-token secrets are kept in MAUI SecureStorage.
- OAuth diagnostic response logging masks token-secret fields.
- The CHPP Consumer Secret remains an application credential; a native client cannot make it truly confidential. Rotate the CHPP secret if it has been exposed and do not commit a newly rotated secret to public source control.
