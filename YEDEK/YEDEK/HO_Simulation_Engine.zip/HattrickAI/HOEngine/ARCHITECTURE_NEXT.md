# HattrickAI — Next Architecture

## Current milestone

The rating layer has been moved toward the public HO! RatingPredictionModel design:

- skill rating: `max(0, skill - 1)`
- loyalty + form based player strength
- experience contribution by sector
- stamina decay by minute and pressing
- specialty/weather modifier hooks
- seven rating sectors
- position side restrictions
- position behaviours
- overcrowding penalties
- HO! sector scaling
- tactic/team context hooks

The implementation is an independent C# implementation; it does not copy Java source files into the MAUI project.

## Data source strategy

The current HTML loader remains the fallback/test source.

Future production flow:

`CHPP OAuth -> XML -> provider -> PlayerData/MatchData -> HOEngine`

The engine must not know whether its data came from HTML or CHPP.

## Training strategy

`TrainingReport` and `TrainingEvent` are now modelled separately from current player state. This allows weekly reports to become a player-development history without changing the rating engine API.

## Next engineering milestones

1. Validate player HTML parsing for form/stamina/experience/loyalty/specialty against a real saved Hattrick page.
2. Add CHPP provider behind an interface once CHPP application credentials/approval are available.
3. Expand formations and role/behaviour search.
4. Calibrate MatchSimulator against the same historical matches used for HO! comparison.
5. Store prediction vs actual result and compute model error metrics.
6. Add a web API/front-end that consumes the same HOEngine.
7. Deploy web front-end on a free static host; keep secrets/OAuth callbacks on a server-side component.

## CHPP integration (v1.1)

The approved CHPP path is now wired through OAuth 1.0a and the CHPP XML API.
The mobile app does not ask for or store a Hattrick password/security code.
The first connection asks for the CHPP product Consumer Key/Consumer Secret, opens Hattrick authorization, accepts the OAuth verifier, then stores the resulting access token in platform SecureStorage.

Initial XML sources:
- teamdetails v1.7
- players v1.3

The HTML loader remains as an offline/manual fallback only. CHPP data uses XML.
