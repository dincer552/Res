# HattrickAI v24 – Modern Dark MAUI UI

This update preserves the existing CHPP OAuth, fixture, opponent-history, rating, lineup and recommendation code paths. The MainPage UI was redesigned to follow the supplied dark football analytics mockup.

## UI
- Dark navy/green responsive MAUI layout
- Desktop sidebar + mobile bottom navigation
- CHPP connected status and connect button
- Fixture cards
- Selected match header
- Opponent vs own formation pitch comparison
- 4-4-2 player placement using existing lineup renderer
- Horizontal selectable opponent recent-match cards
- Recommendation/probability panels
- Explanation and rating panels
- Responsive phone stacking for match, pitches and recommendation sections

No CHPP/data-engine changes were intentionally made in this UI pass.
